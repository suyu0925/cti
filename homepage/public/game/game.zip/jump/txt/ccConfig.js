var ccConfig = {
	"showFPS": false, 
	"frameRate": 60, 
	"project_type": "javascript", 
	"debugMode": 0, 
	"renderMode": 1, 
	"id": "gameCanvas"
};

document["ccConfig"] = ccConfig;